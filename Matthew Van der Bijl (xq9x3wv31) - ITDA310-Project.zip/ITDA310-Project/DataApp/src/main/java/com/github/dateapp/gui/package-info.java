/**
 * @see javax.swing.JFrame
 * @see javax.swing.JDialog
 * 
 * @author Matthew Van der Bijl (xq9x3wv31)
 */
package com.github.dateapp.gui;
